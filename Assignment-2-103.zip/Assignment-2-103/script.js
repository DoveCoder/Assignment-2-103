/* 
Assignment 2 FSDI 103
Julian Smith 
*/

//data from user
const product = prompt("Please enter the name desired product: ");
const quantity = prompt("Please enter the quantity of product: ");
const price = prompt("Please enter price of product: ");
const tax = prompt("What is the current tax rate? ");

let netPrice = Number(price) * Number(tax) + Number(price);
netPrice = netPrice * Number(quantity);

if (netPrice) {
    const message = `<p>The total amount to be paid is: $${netPrice}</p>
    <p>For:</p>
    <p>${product.toUpperCase()}</p>
    <p>Priced at $${price}</p>
    <p>At a quantity of ${quantity}</P>
    <p>Thank you for using my app!</p>`;

    document.querySelector("main").innerHTML = message;
} else {
    errorMessage = '<p>The numbers you entered are not valid. Try again.</p>';
    document.querySelector("main").innerHTML = errorMessage;
}

